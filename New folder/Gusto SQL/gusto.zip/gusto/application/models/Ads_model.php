<?php

class Ads_model extends CIF_model
{
    public $_table = 'ads';
    public $_primary_keys = array('ad_id');


}
