<?php

class Blog_model extends CIF_model
{
    public $_table = 'blog';
    public $_primary_keys = array('blog_id');


}
