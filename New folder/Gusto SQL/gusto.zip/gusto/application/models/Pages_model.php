<?php

class Pages_model extends CIF_model
{
    public $_table = 'pages';
    public $_primary_keys = array('page_id');


}
